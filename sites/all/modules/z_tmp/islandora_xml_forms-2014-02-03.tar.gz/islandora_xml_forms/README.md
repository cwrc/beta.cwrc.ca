BUILD STATUS
------------
Current build status:
[![Build Status](https://travis-ci.org/Islandora/islandora_xml_forms.png?branch=7.x)](https://travis-ci.org/Islandora/islandora_xml_forms)

CI Server:
http://jenkins.discoverygarden.ca

ISLANDORA XML FORMS
==================