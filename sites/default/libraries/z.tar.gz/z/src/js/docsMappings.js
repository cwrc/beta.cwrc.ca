{
    "settings": "Settings.html",
    "validation": "Validate_document.html"
}